<!-- <div class="spinner-grow text-info" role="status">
  <span class="sr-only">Loading...</span>
</div> -->

<!-- Loader starts -->
<div class="loader-wrapper">
    <div class="loader bg-white">
        <div class="whirly-loader"> </div>
    </div>
</div>
<!-- Loader ends -->