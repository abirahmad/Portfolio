 <!-- =====>> footer-area <<===== 
    =========================== -->
    <footer id="footer-area" class="footer-all bg-p bg-light-black pt-50 pb-55">
        <div class="footer-images-1">
            <img class="f-images-1" src="assets/img/home1/footer-bg-1.png" alt="">
        </div>
        <div class="container">
            <div class="row">
                <div class="col-lg-6 offset-lg-3">
                    <div class="footer-content">
                        <ul class="footer-lists text-center">
                            <li><a href="#">Home</a></li>
                            <li><a href="#">Price</a></li>
                            <li><a href="#">Blog</a></li>
                            <li><a href="#">Contact</a></li>
                        </ul>
                        <div class="footer-socials-icon text-center">
                            <a href="#"><i class="fab fa-facebook-f"></i></a>
                            <a href="#"><i class="fab fa-twitter"></i></a>
                            <a href="#"><i class="fab fa-linkedin-in"></i></a>
                            <a href="#"><i class="fab fa-instagram"></i></a>
                            <a href="#"><i class="fas fa-basketball-ball"></i></a>
                            <a href="#"><i class="fab fa-google-plus-g"></i></a>
                        </div>
                        <p>Ham followed now ecstatic use speaking exercise may repeated. Him
                            <br> self he evident oh greatly my on inhabit general concern.</p>
                    </div>
                </div>
            </div>
        </div>
    </footer>
    <!-- =====>> End footer-area <<===== 
    =========================== -->

    <!-- =====>> copyright-area <<===== 
    =========================== -->
    <div id="copyright-area">
        <div class="container">
            <div class="row">
                <div class="col-lg-12">
                    2019 All Rights Reserved. - Created by pointtheme
                </div>
            </div>
        </div>
    </div>
    <!-- =====>> End copyright-area <<===== 
    =========================== -->