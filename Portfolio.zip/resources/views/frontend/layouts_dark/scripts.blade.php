   <!-- =====>> Jquery <<===== 
    =========================== -->
    <script src="{{asset('public/frontend/js/jquery.min.js')}}"></script>
    <script src="{{asset('public/frontend/js/popper.min.js')}}"></script>
    <script src="{{asset('public/frontend/js/bootstrap.min.js')}}"></script>
    <script src="{{asset('public/frontend/js/jquery.magnific-popup.min.js')}}"></script>
    <script src="{{asset('public/frontend/js/isotope.pkgd.min.js')}}"></script>
    <script src="{{asset('public/frontend/js/imagesloaded.pkgd.js')}}"></script>
    <script src="{{asset('public/frontend/js/jquery.mCustomScrollbar.concat.min.js')}}"></script>
    <script src="{{asset('public/frontend/js/jQuery-Circle-progressbar.js')}}"></script>
    <script src="{{asset('public/frontend/js/slick.min.js')}}"></script>
    <script src="{{asset('public/frontend/js/script.js')}}"></script>
    <!-- =====>> End Jquery <<===== 
    =========================== -->