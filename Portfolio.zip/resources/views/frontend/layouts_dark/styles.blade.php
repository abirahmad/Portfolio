
<link rel=icon href="{{asset('public/frontend/img/favicon.ico')}}" sizes="20x20" type="image/png">
 <link rel="stylesheet" href="{{asset('public/frontend/css/bootstrap.min.css')}}">
    <link rel="stylesheet" href="{{asset('public/frontend/css/all.min.css')}}">
    <link rel="stylesheet" href="{{asset('public/frontend/css/magnific-popup.css')}}">
    <link rel="stylesheet" href="{{asset('public/frontend/css/slick.css')}}">
    <link rel="stylesheet" href="{{asset('public/frontend/css/style-2.css')}}">
    <link rel="stylesheet" href="{{asset('public/frontend/css/responsive.css')}}">
