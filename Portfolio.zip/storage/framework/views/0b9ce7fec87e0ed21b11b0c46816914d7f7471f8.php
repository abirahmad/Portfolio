 

 <?php $__env->startSection('title'); ?>
 Experience
 <?php $__env->stopSection(); ?>
 <?php $__env->startSection('content'); ?>
<div class="content-wrapper">
	 <section class="content-header">
      <div class="container-fluid">
        <div class="row mb-2">
          <div class="col-sm-6">
            <h1>Experience</h1>
          </div>
          <div class="col-sm-6">
            <ol class="breadcrumb float-sm-right">
              <li class="breadcrumb-item"><a href="#">Home</a></li>
              <li class="breadcrumb-item active">Experience List</li>
            </ol>
          </div>
        </div>
      </div><!-- /.container-fluid -->
    </section>
 <section class="content">

<div class="row">
  <div class="card col-md-5 card-space">
              <div class="card-header">
                <h3 class="card-title">Experience List</h3>
              </div>

              <!-- /.card-header -->
              <div class="card-body">
                <table id="portfolio_table" class="table table-bordered table-striped">
                  <thead>
                  <tr>
                    <th>Organization Name</th>
                    <th>Time Range</th>
                    <th>Action</th>
                  </tr>
                  </thead>
                  <tbody>
                  	<?php $__currentLoopData = $experiences; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $experience): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  	<tr>
                  		<td><?php echo e($experience->organization_name); ?></td>
                  		<td><?php echo e($experience->time_range); ?></td>
                         <td><form id="delete-form" action="<?php echo e(route('admin.experience.delete',$experience->id)); ?>" method="POST">
                          <button type="submit" class="btn btn-danger btn-xs"> <i class="fa fa-trash"> delete</i></button>
                                        <?php echo csrf_field(); ?>
                                    </form></td>
                            
                  	</tr>
              		<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  </tbody>
                </table>
              </div>
              <!-- /.card-body -->
            </div>
            <!-- /.card -->

           	<!-- /.col -->
				<div class="col-md-6">
					<div class="card card-info">
						<div class="card-header">
							<h3 class="card-title">Expereince Add</h3>
						</div>
					
						<!-- /.card-header -->
						<!-- form start -->
						<form action="<?php echo e(route('admin.experience.store')); ?>" method="POST" enctype="multipart/form-data" role="form" id="submit-form">
							<?php echo csrf_field(); ?>
                		<?php echo $__env->make('backend.layouts.partials.messages', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
						<div class="card-body row">
							<div class="col-md-12">
                <div class="form-group">
                  <label for="organization_name">Organization Name</label>
                  <input type="text" name="organization_name" value="" class="form-control" id="exampleInputEmail1" placeholder="Enter Organization Name" required="">
                </div>
								<div class="form-group">
									<label for="time_range">Time Range</label>
									<input type="text" name="time_range" value="" class="form-control" id="exampleInputEmail1" placeholder="Enter Time Range" required="">
								</div>
								<div class="form-group">
                  <label for="theme">Short Description</label>
                  <textarea class="textarea" name="short_description" placeholder="Enter Description"
                                ></textarea>
              </div>
							</div>
						</div>
							<!-- /.card-body -->

							<div class="card-footer">
								<a class="btn btn-primary" href="<?php echo e(route('admin.experience.store')); ?>"
                                       onclick="event.preventDefault();
                                                     document.getElementById('submit-form').submit();">Submit</a>
							</div>
						</form>
					</div>
					<!-- /.card -->
					<!-- /.nav-tabs-custom -->
				</div>
				<!-- /.col -->
            <!-- /.card -->
        	</div>
       </div>
       </section>
 <?php $__env->stopSection(); ?>


<?php echo $__env->make('backend.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Portfolio\resources\views/backend/experience/experience.blade.php ENDPATH**/ ?>