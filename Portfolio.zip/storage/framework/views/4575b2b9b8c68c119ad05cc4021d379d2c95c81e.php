 

 <?php $__env->startSection('title'); ?>
 Banner
 <?php $__env->stopSection(); ?>
 <?php $__env->startSection('content'); ?>
<div class="content-wrapper">
	 <section class="content-header">
      <div class="container-fluid">
        <div class="row mb-2">
          <div class="col-sm-6">
            <h1>Banner</h1>
          </div>
          <div class="col-sm-6">
            <ol class="breadcrumb float-sm-right">
              <li class="breadcrumb-item"><a href="#">Home</a></li>
              <li class="breadcrumb-item active">Banner Update</li>
            </ol>
          </div>
        </div>
      </div><!-- /.container-fluid -->
    </section>
 <section class="content">

<div class="row">
           	<!-- /.col -->
				<div class="col-md-12">
					<div class="card card-info">
						<div class="card-header">
							<h3 class="card-title">Banner Update</h3>
						</div>
					
						<!-- /.card-header -->
						<!-- form start -->
						<form action="<?php echo e(route('admin.banners.update')); ?>" method="POST" enctype="multipart/form-data" role="form" id="submit-form">
							<?php echo csrf_field(); ?>
                		<?php echo $__env->make('backend.layouts.partials.messages', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
						<div class="card-body row">
							<div class="col-md-12">
                <div class="form-group">
                  <label for="title">Title</label>
                  <input type="text" name="title" value="<?php echo e($banners->title); ?>" class="form-control" id="exampleInputEmail1" placeholder="Enter Title" required="">
                </div>
								<div class="form-group">
									<label for="name">User Name <span style="color: blue">(Optional)</span> </label>
									<input type="text" name="name" value="<?php echo e($banners->name); ?>" class="form-control" id="exampleInputEmail1" placeholder="Enter User Name" required="">
								</div>

                <div class="form-group">
                  <label for="image">Old Banner Image</label>
                  <img class="display-img " src="<?php echo e(url('public/backend/images/banner/'.$banners->image)); ?>">
                </div>
                <div class="form-group">
                  <label for="image">Banner Image</label>
                  <input type="file" name="image" class="form-control" id="exampleInputEmail1" placeholder="Enter Service Title" required="">
                </div>
                 <div class="form-group">
                  <label for="image">Old CV</label>
                  <a href="<?php echo e(url('/')); ?>/public/backend/images/cv/<?php echo e($banners->cv_upload); ?>" target="_blank">Download CV</a>
                </div>
                 <div class="form-group">
                  <label for="cv_upload">CV Upload</label>
                  <input data-allowed-file-extensions="pdf doc docx pptx" data-max-file-size="5M" data-height="150"
                                type="file" class="form-control dropify" id="file" aria-describedby="emailHelp" name="cv_upload" required>
                </div>
								<div class="form-group">
                  <label for="theme">Description</label>
                  <textarea class="textarea" name="description" placeholder="Enter Description"
                                ><?php echo e($banners->description); ?></textarea>
              </div>
							</div>
						</div>
							<!-- /.card-body -->

							<div class="card-footer">
								<a class="btn btn-primary" href="<?php echo e(route('admin.banners.update')); ?>"
                                       onclick="event.preventDefault();
                                                     document.getElementById('submit-form').submit();">Submit</a>
							</div>
						</form>
					</div>
					<!-- /.card -->
					<!-- /.nav-tabs-custom -->
				</div>
				<!-- /.col -->
            <!-- /.card -->
        	</div>
       </div>
       </section>
 <?php $__env->stopSection(); ?>


<?php echo $__env->make('backend.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Portfolio\resources\views/backend/banners/banner.blade.php ENDPATH**/ ?>