<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<title><?php echo $__env->yieldContent('title'); ?> | Log in</title>
	<!-- Tell the browser to be responsive to screen width -->
	<meta name="viewport" content="width=device-width, initial-scale=1">

	<?php echo $__env->make('backend.layouts.partials.styles', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

</head>
<body class="hold-transition login-page">
	<!-- Loader -->
	<?php echo $__env->make('backend.layouts.partials.loader', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
	<!-- Loader -->
	
	<!-- Main Content -->
	<?php echo $__env->yieldContent('login-content'); ?>
	<!-- Main Content -->
	

	<!-- Scripts -->
	<?php echo $__env->make('backend.layouts.partials.scripts', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
	<!-- Scripts -->

</body>
</html>
<?php /**PATH C:\xampp\htdocs\Portfolio\resources\views/backend/auth/auth_master.blade.php ENDPATH**/ ?>