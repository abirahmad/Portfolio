
      <li class="nav-item">
        <a class="nav-link" data-widget="control-sidebar" data-slide="true" href="#" role="button"><i
            class="fas fa-th-large"></i></a>
      </li>
  <!-- /.navbar --><?php /**PATH C:\xampp\htdocs\Portfolio\resources\views/backend/layouts/partials/nav.blade.php ENDPATH**/ ?>