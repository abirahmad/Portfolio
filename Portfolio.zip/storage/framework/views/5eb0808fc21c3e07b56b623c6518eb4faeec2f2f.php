   <!-- =====>> Jquery <<===== 
    =========================== -->
    <script src="<?php echo e(asset('public/frontend/js/jquery.min.js')); ?>"></script>
    <script src="<?php echo e(asset('public/frontend/js/popper.min.js')); ?>"></script>
    <script src="<?php echo e(asset('public/frontend/js/bootstrap.min.js')); ?>"></script>
    <script src="<?php echo e(asset('public/frontend/js/jquery.magnific-popup.min.js')); ?>"></script>
    <script src="<?php echo e(asset('public/frontend/js/isotope.pkgd.min.js')); ?>"></script>
    <script src="<?php echo e(asset('public/frontend/js/imagesloaded.pkgd.js')); ?>"></script>
    <script src="<?php echo e(asset('public/frontend/js/jquery.mCustomScrollbar.concat.min.js')); ?>"></script>
    <script src="<?php echo e(asset('public/frontend/js/jQuery-Circle-progressbar.js')); ?>"></script>
    <!-- <script src="<?php echo e(asset('public/frontend/js/slick.min.js')); ?>"></script> -->
    <script src="<?php echo e(asset('public/frontend/js/script.js')); ?>"></script>
    <!-- =====>> End Jquery <<===== 
    =========================== --><?php /**PATH C:\xampp\htdocs\Portfolio\resources\views/frontend/layouts_light/scripts.blade.php ENDPATH**/ ?>