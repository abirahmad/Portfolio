 

 <?php $__env->startSection('title'); ?>
 Menu
 <?php $__env->stopSection(); ?>
 <?php $__env->startSection('content'); ?>
<div class="content-wrapper">
	 <section class="content-header">
      <div class="container-fluid">
        <div class="row mb-2">
          <div class="col-sm-6">
            <h1>Menus</h1>
          </div>
          <div class="col-sm-6">
            <ol class="breadcrumb float-sm-right">
              <li class="breadcrumb-item"><a href="#">Home</a></li>
              <li class="breadcrumb-item active">Menus</li>
            </ol>
          </div>
        </div>
      </div><!-- /.container-fluid -->
    </section>
 <section class="content">

<div class="row">
  <div class="card col-md-5 card-space">
              <div class="card-header">
                <h3 class="card-title">Menu List</h3>
              </div>

              <!-- /.card-header -->
              <div class="card-body">
                <table id="portfolio_table" class="table table-bordered table-striped">
                  <thead>
                  <tr>
                    <th>Menu Title</th>
                    <th>Action</th>
                  </tr>
                  </thead>
                  <tbody>
                  	<?php $__currentLoopData = $menus; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $menu): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  	<tr>
                  		<td><?php echo e($menu->name); ?></td>
                         <td><form id="delete-form" action="<?php echo e(route('admin.menus.delete',$menu->id)); ?>" method="POST">
                          <button type="submit" class="btn btn-danger btn-xs"> <i class="fa fa-trash"> delete</i></button>
                                        <?php echo csrf_field(); ?>
                                    </form></td>
                            
                  	</tr>
              		<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  </tbody>
                  <tfoot>
                  <tr>
                    <th>Menu Title</th>
                    <th>Action</th>
                  </tr>
                  </tfoot>
                </table>
              </div>
              <!-- /.card-body -->
            </div>
            <!-- /.card -->

           	<!-- /.col -->
				<div class="col-md-5">
					<div class="card card-info">
						<div class="card-header">
							<h3 class="card-title">Menu Add</h3>
						</div>
					
						<!-- /.card-header -->
						<!-- form start -->
						<form id="submit-form" action="<?php echo e(route('admin.menus.store')); ?>" method="POST" enctype="multipart/form-data" role="form" id="quickForm">
							<?php echo csrf_field(); ?>
                <?php echo $__env->make('backend.layouts.partials.messages', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
							<div class="card-body row">
								<div class="col-md-12">
								<div class="form-group">
									<label for="name">Menu Title</label>
									<input type="text" name="name" value="" class="form-control" id="exampleInputEmail1" placeholder="Enter Menu Title" required="">
								</div>
							</div>
						</div>
							<!-- /.card-body -->

							<div class="card-footer">
								<a class="btn btn-primary" href="<?php echo e(route('admin.menus.store')); ?>"
                                       onclick="event.preventDefault();
                                                     document.getElementById('submit-form').submit();">Submit</a>
							</div>
						</form>
					</div>
					<!-- /.card -->
					<!-- /.nav-tabs-custom -->
				</div>
				<!-- /.col -->
            <!-- /.card -->
        	</div>
       </div>
       </section>
 <?php $__env->stopSection(); ?>


<?php echo $__env->make('backend.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Portfolio\resources\views/backend/menus/menu.blade.php ENDPATH**/ ?>