<?php $__env->startSection('title'); ?>
My Portfolio
<?php $__env->stopSection(); ?>

<?php $__env->startSection('login-content'); ?>

<div class="login-box">
        <div class="login-logo">
            <a href="<?php echo e(route('login')); ?>"><b>My</b>PORTFOLIO</a>
        </div>
        <!-- /.login-logo -->
        <div class="card">
            <div class="card-body login-card-body">
                <p class="login-box-msg">Sign in to start your session</p>

                <form action="<?php echo e(route('admin.login.submit')); ?>" method="post">
                    <?php echo csrf_field(); ?>
                    <!-- <?php echo $__env->make('backend.layouts.partials.messages', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?> -->
                    <div class="input-group mb-3">
                        <input type="username" name="username" value="<?php echo e(old('username')); ?>" class="form-control" placeholder="Username">
                        <div class="input-group-append">
                            <div class="input-group-text">
                                <span class="fas fa-user"></span>
                            </div>
                        </div>
                    </div>
                    <div class="input-group mb-3">
                        <input type="password" name="password" class="form-control" placeholder="Password">
                        <div class="input-group-append">
                            <div class="input-group-text">
                                <span class="fas fa-lock"></span>
                            </div>
                        </div>
                    </div>
                      <div class="row">
                        <div class="col-8">
                            <div class="icheck-primary">
                                <input type="checkbox" id="remember">
                                <label for="remember">
                                    Remember Me
                                </label>
                            </div>
                        </div>
                    </div>
                      <div class="social-auth-links text-center mb-3">
                            <button  type="submit" class="btn btn-block btn-primary">
                                <i class="fa fa-sign-in mb-2" aria-hidden="true"></i> Sign in
                            </button>
                      </div>
                  
                </form>

                <div class="social-auth-links text-center mb-3">
                    <p>- OR -</p>
                    <a href="<?php echo e(route('login.facebook')); ?>" class="btn btn-block btn-primary">
                      <i class="fab fa-facebook mr-2"></i> Sign in using Facebook
                    </a>
                </div>
                <!-- /.social-auth-links -->

                <p class="mb-1">
                    <a href="forgot-password.html">I forgot my password</a>
                </p>
                <p class="mb-0">
                    <a href="register.html" class="text-center">Register a new membership</a>
                </p>
            </div>
            <!-- /.login-card-body -->
        </div>
    </div>
    <!-- /.login-box -->
<?php $__env->stopSection(); ?>
<?php echo $__env->make('backend.auth.auth_master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Portfolio\resources\views/backend/auth/login.blade.php ENDPATH**/ ?>