

<?php if($errors->any()): ?>
  <div class="row justify-content-center">
    <div class="col-md-12">
      <div class="alert alert-danger">
        <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
        <ul>
          <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <p><?php echo e($error); ?></p>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>
      </div>
    </div>
  </div>
<?php endif; ?>

<?php if(Session::has('success')): ?>
  <script>
  new Noty({
    theme: 'sunset',
    type: 'info',
    layout: 'topRight',
    text: "<?php echo Session::get('success'); ?>",
    timeout: 2000
  }).show();
  </script>
<?php endif; ?>

<?php if(Session::has('error')): ?>
  <script>
  //new Noty({
   // theme: 'sunset',
   // type: 'error',
   // layout: 'topCenter',
   // text: "<?php echo Session::get('error'); ?>",
   // timeout: 2000
  // }).show();
  
  var notify = $.notify("<?php echo Session::get('error'); ?>", {
        type: 'theme',
        allow_dismiss: true,
        delay: 2000,
        timer: 300
    });
  </script>
<?php endif; ?>

<?php if(Session::has('sticky_error')): ?>
  <div class="row justify-content-center">
    <div class="col-md-12">
      <div class="alert alert-danger">
        <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
        <?php echo Session::get('sticky_error'); ?>

      </div>
    </div>
  </div>
<?php endif; ?>

<?php if(Session::has('db_error')): ?>
  <div class="row justify-content-center">
    <div class="col-md-12">
      <div class="alert alert-danger">
        <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
        <?php echo Session::get('db_error'); ?>

      </div>
    </div>
  </div>
<?php endif; ?>

<?php if(Session::has('sticky_success')): ?>
  <div class="row justify-content-center">
    <div class="col-md-12">
      <div class="alert alert-success">
        <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
        <?php echo Session::get('sticky_success'); ?>

      </div>
    </div>
  </div>
<?php endif; ?>

<?php if(Session::has('message')): ?>
  <div class="row justify-content-center">
    <div class="col-md-12">
      <div class="alert alert-info">
        <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
        <?php echo Session::get('message'); ?>

      </div>
    </div>
  </div>
<?php endif; ?>

<?php if(Session::has('login_error')): ?>
<div class="row justify-content-center mb-3">
    <div class="col-md-12">
        <div class="alert alert-danger">
        <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
        <?php echo Session::get('login_error'); ?>

        </div>
    </div>
</div>
<?php endif; ?>
<?php /**PATH C:\xampp\htdocs\Portfolio\resources\views/backend/layouts/partials/messages.blade.php ENDPATH**/ ?>