<?php if(Session::has('success')): ?>
<script>
  new Noty({
    theme: 'sunset',
    type: 'success',
    layout: 'topCenter',
    text: "<?php echo Session::get('success'); ?>",
    timeout: 2000
  }).show();
</script>
<?php endif; ?>

<?php if(Session::has('error')): ?>
<script>
  new Noty({
      theme: 'sunset',
      type: 'error',
      layout: 'topCenter',
      text: "<?php echo Session::get('error'); ?>",
      timeout: 2000
    }).show();
</script>
<?php endif; ?><?php /**PATH C:\xampp\htdocs\Portfolio\resources\views/backend/layouts/partials/flash-messages.blade.php ENDPATH**/ ?>