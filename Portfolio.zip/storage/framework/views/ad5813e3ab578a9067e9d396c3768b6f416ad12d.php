 <!-- Center Nav -->
    <nav class="navbar navbar-expand-lg navbar-light menu-two" id="navigation">
        <div class="container">
            <a class="navbar-brand" href="#">
                <img src="<?php echo e(asset('public/frontend/img/home-2/logo-2.png')); ?>" alt="">
            </a>
            <div class="collapse navbar-collapse">
                <ul class="nav navbar-nav ml-auto">
                    <li class="nav-item active">
                        <a class="nav-link" href="#">HOME</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="#introduce-area2">ABOUT</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="#progress-bar-area">SKILL</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="#experience-area">EXPERICENCE</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="#portfolio-area">PORTFOLIO</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="#testimonial-area2">TESTIMONIAL</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="#block-area2">BLOG</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="#touch-area2">CONTACT</a>
                    </li>
                </ul>
            </div>
            <button type="button" id="sidebarCollapse" class="btn">
                <i class="fa fa-bars"></i>
            </button>
        </div>
    </nav>
    <!-- =====>> End Menu area <<===== 
    =========================== --><?php /**PATH C:\xampp\htdocs\Portfolio\resources\views/frontend/layouts/sidebar.blade.php ENDPATH**/ ?>