

<?php $__env->startSection('title'); ?>
Portfolio
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

    <section id="portfolio-area" class="bg-white pt-130 pb-130">
        <div class="container">
            <div class="row">
                <div class="col-lg-6 offset-lg-3">
                    <div class="section-title-2 text-center">
                        <h2>My Portfolio</h2>
                        <div class="section-title-border-center-2"></div>
                    </div>
                </div>
            </div>
            <?php
            $menus=App\Models\Menu::orderBy('id','desc')->get();
              ?>
            <div class="row mt-40">
                <div class="col-lg-12">
                    <div class="isotoop-btns text-center">
                        <div class="button-group filter-button-group">
                            <button class="active" data-filter="*">All Work</button>
                            <?php $__currentLoopData = $menus; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $menu): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <button data-filter="<?php echo e($menu->id); ?>"><?php echo e($menu->name); ?></button>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                    </div>
                </div>
            </div>
            <div class="portfolio-filters images-loads mt-20">
                <div class="row">
                    <div class="col-lg-4 grid-item z2 z3 z5 mt-30 col-sm-6 col-md-6">
                        <div class="timelined-portfolio-all">
                            <div class="port-img-timelined">
                                <img src="<?php echo e(asset('public/frontend/img/home1/port-img-1.png')); ?>" alt="">
                                <h6>Design for Client
                                    <br> Design for Client</h6>
                            </div>
                            <div class="port-hover-icons-2">
                                <a class="images-gallery" href="<?php echo e(asset('public/frontend/img/home1/port-img-1.png')); ?>"><i
                                        class="fa fa-search-plus"></i></a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <?php $__env->stopSection(); ?>
<?php echo $__env->make('frontend.layouts_light.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Portfolio\resources\views/frontend/layouts_light/portfolios.blade.php ENDPATH**/ ?>