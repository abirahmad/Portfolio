
<link rel=icon href="<?php echo e(asset('public/frontend/img/favicon.ico')); ?>" sizes="20x20" type="image/png">
 <link rel="stylesheet" href="<?php echo e(asset('public/frontend/css/bootstrap.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('public/frontend/css/all.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('public/frontend/css/magnific-popup.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('public/frontend/css/slick.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('public/frontend/css/style-2.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('public/frontend/css/responsive.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('public/frontend/css/custom.css')); ?>"><?php /**PATH C:\xampp\htdocs\Portfolio\resources\views/frontend/layouts_light/styles.blade.php ENDPATH**/ ?>