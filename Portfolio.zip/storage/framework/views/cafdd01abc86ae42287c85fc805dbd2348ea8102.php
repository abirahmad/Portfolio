
  <!-- Font Awesome -->
  <link rel="stylesheet" href="<?php echo e(asset('public/backend/plugins/fontawesome-free/css/all.min.css')); ?>">
    <!-- Notify -->
<link rel="stylesheet" type="text/css" href="<?php echo e(asset('public/backend/css/noty.min.css')); ?>">
<!-- Notify -->
  <!-- Ionicons -->
  <link rel="stylesheet" href="https://code.ionicframework.com/ionicons/2.0.1/css/ionicons.min.css">
  <!-- icheck bootstrap -->
  <link rel="stylesheet" href="<?php echo e(asset('public/backend/plugins/icheck-bootstrap/icheck-bootstrap.min.css')); ?>">

  <link rel="stylesheet" href="<?php echo e(asset('public/backend/plugins/daterangepicker/daterangepicker.css')); ?>">
  <link rel="stylesheet" href="<?php echo e(asset('public/backend/plugins/bootstrap-switch/css/bootstrap3/bootstrap-switch.css')); ?>">
   <!-- iCheck for checkboxes and radio inputs -->
  <link rel="stylesheet" href="<?php echo e(asset('public/backend/plugins/icheck-bootstrap/icheck-bootstrap.min.css')); ?>">
  <!-- Theme style -->
  <link rel="stylesheet" href="<?php echo e(asset('public/backend/dist/css/adminlte.min.css')); ?>">
  <!-- Google Font: Source Sans Pro -->
  <link href="https://fonts.googleapis.com/css?family=Source+Sans+Pro:300,400,400i,700" rel="stylesheet">
  <!-- summernote -->
  <link rel="stylesheet" href="<?php echo e(asset('public/backend/plugins/summernote/summernote-bs4.css')); ?>">
  <!-- DataTables -->
  <link rel="stylesheet" href="<?php echo e(asset('public/backend/plugins/datatables-bs4/css/dataTables.bootstrap4.min.css')); ?>">
  <link rel="stylesheet" href="<?php echo e(asset('public/backend/plugins/datatables-responsive/css/responsive.bootstrap4.min.css')); ?>">



<?php /**PATH C:\xampp\htdocs\Portfolio\resources\views/backend/layouts/partials/styles.blade.php ENDPATH**/ ?>