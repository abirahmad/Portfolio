 <!-- =====>> footer-area2 <<===== 
    =========================== -->
    <footer id="footer-area2" class="footer-all-2 pt-50 pb-55">
        <div class="container">
            <div class="row">
                <div class="col-lg-6 offset-lg-3">
                    <div class="footer-content-2">
                        <ul class="footer-lists-2 text-center">
                            <li><a href="#">Home</a></li>
                            <li><a href="#">Price</a></li>
                            <li><a href="#">Blog</a></li>
                            <li><a href="#">Contact</a></li>
                        </ul>
                        <div class="footer-socials-icon-2 text-center">
                            <a href="#"><i class="fab fa-facebook-f"></i></a>
                            <a href="#"><i class="fab fa-twitter"></i></a>
                            <a href="#"><i class="fab fa-linkedin-in"></i></a>
                            <a href="#"><i class="fab fa-instagram"></i></a>
                            <a href="#"><i class="fas fa-basketball-ball"></i></a>
                            <a href="#"><i class="fab fa-google-plus-g"></i></a>
                        </div>
                        <p>Ham followed now ecstatic use speaking exercise may repeated. Him
                            <br> self he evident oh greatly my on inhabit general concern.</p>
                    </div>
                </div>
            </div>
        </div>
    </footer>
    <!-- =====>> End footer-area2 <<===== 
    =========================== -->

    <!-- =====>> copyright-area2 <<===== 
    =========================== -->
    <div id="copyright-area-2">
        <div class="container">
            <div class="row">
                <div class="col-lg-12">
                    2019 All Rights Reserved. - Created by pointtheme
                </div>
            </div>
        </div>
    </div>
    <!-- =====>> End copyright-area <<===== 
    =========================== -->
    <!-- =====>> scrolltop2 <<===== 
    =========================== -->
    <a class="scrollsTop scrollsTop-2" href="#"><i class="fas fa-caret-up"></i></a>
    <!-- =====>> End scrolltop2 <<===== 
    =========================== --><?php /**PATH C:\xampp\htdocs\Portfolio\resources\views/frontend/layouts/footer.blade.php ENDPATH**/ ?>