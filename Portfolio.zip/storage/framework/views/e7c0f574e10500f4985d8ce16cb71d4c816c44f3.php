<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>HIN - Personal Portfolio HTML Template</title>
    <?php echo $__env->make('frontend.layouts_dark.styles', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</head>

<body>

    <!-- ===========================
    =====>> Top Preloader <<===== -->
  <!--   <div id="preloader">
        <div class="lds-css">
            <div class="preloader-3">
                <span></span>
                <span></span>
            </div>
        </div>
    </div> -->
   <?php echo $__env->make('frontend.layouts_dark.top_header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

   <?php echo $__env->make('frontend.layouts_dark.sidebarnav', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

   <?php echo $__env->make('frontend.layouts_dark.navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

   <?php echo $__env->yieldContent('content'); ?> 
   
   <?php echo $__env->make('frontend.layouts_dark.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <!-- =====>> scrolltop <<===== 
    =========================== -->
    <a class="scrollsTop" href="#"><i class="fas fa-caret-up"></i></a>

    <!-- =====>> End scrolltop <<===== 
    =========================== -->


  <?php echo $__env->make('frontend.layouts_dark.scripts', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>


</body>

</html><?php /**PATH C:\xampp\htdocs\Portfolio\resources\views/frontend/layouts_dark/master.blade.php ENDPATH**/ ?>