<script src="<?php echo e(asset('public/backend/plugins/jquery/jquery.min.js')); ?>"></script>
    <!-- Bootstrap 4 -->
    <script src="<?php echo e(asset('public/backend/plugins/bootstrap/js/bootstrap.bundle.min.js')); ?>"></script>
    <!-- AdminLTE App -->
    <script src="<?php echo e(asset('public/backend/dist/js/adminlte.min.js')); ?>"></script>
    <!-- Toaster-->
<script src="<?php echo e(asset('public/backend/js/noty/noty.min.js')); ?>"></script>
<!-- Bootstrap Switch -->
<script src="<?php echo e(asset('public/backend/plugins/bootstrap-switch/js/bootstrap-switch.min.js')); ?>"></script>

<!-- Editor -->
<!-- AdminLTE for demo purposes -->
<script src="<?php echo e(asset('public/backend/dist/js/demo.js')); ?>"></script>
<!-- Summernote -->
<script src="<?php echo e(asset('public/backend/plugins/summernote/summernote-bs4.min.js')); ?>"></script>
<script>
  $(function () {
    // Summernote
    $('.textarea').summernote()
  })
</script>
<!-- DataTables -->
<script src="<?php echo e(asset('public/backend/plugins/datatables/jquery.dataTables.min.js')); ?>"></script>
<script src="<?php echo e(asset('public/backend/plugins/datatables-bs4/js/dataTables.bootstrap4.min.js')); ?>"></script>
<script src="<?php echo e(asset('public/backend/plugins/datatables-responsive/js/dataTables.responsive.min.js')); ?>"></script>
<script src="<?php echo e(asset('public/backend/plugins/datatables-responsive/js/responsive.bootstrap4.min.js')); ?>"></script>
<!-- page script -->
      <?php echo $__env->make('backend.layouts.partials.messages', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Portfolio\resources\views/backend/layouts/partials/scripts.blade.php ENDPATH**/ ?>