   <!--
    ========================================
        header-top-area2
    ========================================
    -->
    <header class="header-top-area header-top-area-2">
        <div class="container">
            <div class="row">
                <div class="col-lg-8 col-md-10 col-sm-9">
                    <div class="header-content header-content-2">
                        <ul class="header-contact header-contact-2">
                            <li>
                                <i class="fas fa-phone"></i>
                                <a href="#">1 855-244-5476</a>
                            </li>
                            <li>
                                <i class="fas fa-map-marker-alt"></i>
                                <a href="#">10940 SW Road #217 Portland, OR97225</a>
                            </li>
                            <li>
                                <i class="far fa-envelope"></i>
                                <a href="#">SALES@AGILIRON.COM</a>
                            </li>
                        </ul>
                    </div>
                </div>
                <div class="col-lg-4 col-md-2 col-sm-3">
                    <a href="#" class="header-top-right-text text-center">
                        FREE CONSULTATION
                    </a>
                </div>
            </div>
        </div>
    </header>
    <!--
    ========================================
        End header-top-area2
    ========================================
    -->
    <!--
    ========================================
        menu-area
    ========================================
    --><?php /**PATH C:\xampp\htdocs\Portfolio\resources\views/frontend/layouts_dark/top_header.blade.php ENDPATH**/ ?>